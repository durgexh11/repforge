// Exercise instructions + photo folders (images/<id>/0.jpg, 1.jpg)
// Source: free-exercise-db (Unlicense / public domain)
const EX_DB = {
 "Incline_Push-Up": {
  "name": "Incline Push-Up",
  "muscle": "chest",
  "level": "beginner",
  "steps": [
   "Stand facing bench or sturdy elevated platform. Place hands on edge of bench or platform, slightly wider than shoulder width.",
   "Position forefoot back from bench or platform with arms and body straight. Arms should be perpendicular to body. Keeping body straight, lower chest to edge of box or platform by bending arms.",
   "Push body up until arms are extended. Repeat."
  ]
 },
 "Pushups": {
  "name": "Pushups",
  "muscle": "chest",
  "level": "beginner",
  "steps": [
   "Lie on the floor face down and place your hands about 36 inches apart while holding your torso up at arms length.",
   "Next, lower yourself downward until your chest almost touches the floor as you inhale.",
   "Now breathe out and press your upper body back up to the starting position while squeezing your chest.",
   "After a brief pause at the top contracted position, you can begin to lower yourself downward again for as many repetitions as needed."
  ]
 },
 "Push-Up_Wide": {
  "name": "Push-Up Wide",
  "muscle": "chest",
  "level": "beginner",
  "steps": [
   "With your hands wide apart, support your body on your toes and hands in a plank position. Your elbows should be extended and your body straight. Do not allow your hips to sag. This will be your starting position.",
   "To begin, allow the elbows to flex, lowering your chest to the floor as you inhale.",
   "Using your pectoral muscles, press your upper body back up to the starting position by extending the elbows. Exhale as you perform this step.",
   "After pausing at the contracted position, repeat the movement for the prescribed amount of repetitions."
  ]
 },
 "Incline_Push-Up_Close-Grip": {
  "name": "Incline Push-Up Close-Grip",
  "muscle": "triceps",
  "level": "beginner",
  "steps": [
   "Stand facing a Smith machine bar or sturdy elevated platform at an appropriate height.",
   "Place your hands next to one another on the bar.",
   "Position your feet back from the bar with arms and body straight. This will be your starting position.",
   "Keeping your body straight, lower your chest to the bar by bending the arms."
  ]
 },
 "Dumbbell_Bench_Press": {
  "name": "Dumbbell Bench Press",
  "muscle": "chest",
  "level": "beginner",
  "steps": [
   "Lie down on a flat bench with a dumbbell in each hand resting on top of your thighs. The palms of your hands will be facing each other.",
   "Then, using your thighs to help raise the dumbbells up, lift the dumbbells one at a time so that you can hold them in front of you at shoulder width.",
   "Once at shoulder width, rotate your wrists forward so that the palms of your hands are facing away from you. The dumbbells should be just to the sides of your chest, with your upper arm and forearm creating a 90 degree angle. Be sure to maintain full control of the dumbbells at all times. This will be your starting position.",
   "Then, as you breathe out, use your chest to push the dumbbells up. Lock your arms at the top of the lift and squeeze your chest, hold for a second and then begin coming down slowly. Tip: Ideally, lowering the weight should take about twice as long as raising it."
  ]
 },
 "Bench_Press_-_With_Bands": {
  "name": "Bench Press - With Bands",
  "muscle": "chest",
  "level": "beginner",
  "steps": [
   "Using a flat bench secure a band under the leg of the bench that is nearest to your head.",
   "Once the band is secure, grab it by both handles and lie down on the bench.",
   "Extend your arms so that you are holding the band handles in front of you at shoulder width.",
   "Once at shoulder width, rotate your wrists forward so that the palms of your hands are facing away from you. This will be your starting position."
  ]
 },
 "Machine_Bench_Press": {
  "name": "Machine Bench Press",
  "muscle": "chest",
  "level": "beginner",
  "steps": [
   "Sit down on the Chest Press Machine and select the weight.",
   "Step on the lever provided by the machine since it will help you to bring the handles forward so that you can grab the handles and fully extend the arms.",
   "Grab the handles with a palms-down grip and lift your elbows so that your upper arms are parallel to the floor to the sides of your torso. Tip: Your forearms will be pointing forward since you are grabbing the handles. Once you bring the handles forward and extend the arms you will be at the starting position.",
   "Now bring the handles back towards you as you breathe in."
  ]
 },
 "Superman": {
  "name": "Superman",
  "muscle": "lower back",
  "level": "beginner",
  "steps": [
   "To begin, lie straight and face down on the floor or exercise mat. Your arms should be fully extended in front of you. This is the starting position.",
   "Simultaneously raise your arms, legs, and chest off of the floor and hold this contraction for 2 seconds. Tip: Squeeze your lower back to get the best results from this exercise. Remember to exhale during this movement. Note: When holding the contracted position, you should look like superman when he is flying.",
   "Slowly begin to lower your arms, legs and chest back down to the starting position while inhaling.",
   "Repeat for the recommended amount of repetitions prescribed in your program."
  ]
 },
 "One-Arm_Dumbbell_Row": {
  "name": "One-Arm Dumbbell Row",
  "muscle": "middle back",
  "level": "beginner",
  "steps": [
   "Choose a flat bench and place a dumbbell on each side of it.",
   "Place the right leg on top of the end of the bench, bend your torso forward from the waist until your upper body is parallel to the floor, and place your right hand on the other end of the bench for support.",
   "Use the left hand to pick up the dumbbell on the floor and hold the weight while keeping your lower back straight. The palm of the hand should be facing your torso. This will be your starting position.",
   "Pull the resistance straight up to the side of your chest, keeping your upper arm close to your side and keeping the torso stationary. Breathe out as you perform this step. Tip: Concentrate on squeezing the back muscles once you reach the full contracted position. Also, make sure that the force is performed with the back muscles and not the arms. Finally, the upper torso should remain stationary and only the arms should move. The forearms should do no other work except for holding the dumbbell; therefore do not try to pull the dumbbell up using the forearms."
  ]
 },
 "Band_Pull_Apart": {
  "name": "Band Pull Apart",
  "muscle": "shoulders",
  "level": "beginner",
  "steps": [
   "Begin with your arms extended straight out in front of you, holding the band with both hands.",
   "Initiate the movement by performing a reverse fly motion, moving your hands out laterally to your sides.",
   "Keep your elbows extended as you perform the movement, bringing the band to your chest. Ensure that you keep your shoulders back during the exercise.",
   "Pause as you complete the movement, returning to the starting position under control."
  ]
 },
 "Back_Flyes_-_With_Bands": {
  "name": "Back Flyes - With Bands",
  "muscle": "shoulders",
  "level": "beginner",
  "steps": [
   "Run a band around a stationary post like that of a squat rack.",
   "Grab the band by the handles and stand back so that the tension in the band rises.",
   "Extend and lift the arms straight in front of you. Tip: Your arms should be straight and parallel to the floor while perpendicular to your torso. Your feet should be firmly planted on the floor spread at shoulder width. This will be your starting position.",
   "As you exhale, move your arms to the sides and back. Keep your arms extended and parallel to the floor. Continue the movement until the arms are extended to your sides."
  ]
 },
 "Seated_Cable_Rows": {
  "name": "Seated Cable Rows",
  "muscle": "middle back",
  "level": "beginner",
  "steps": [
   "For this exercise you will need access to a low pulley row machine with a V-bar. Note: The V-bar will enable you to have a neutral grip where the palms of your hands face each other. To get into the starting position, first sit down on the machine and place your feet on the front platform or crossbar provided making sure that your knees are slightly bent and not locked.",
   "Lean over as you keep the natural alignment of your back and grab the V-bar handles.",
   "With your arms extended pull back until your torso is at a 90-degree angle from your legs. Your back should be slightly arched and your chest should be sticking out. You should be feeling a nice stretch on your lats as you hold the bar in front of you. This is the starting position of the exercise.",
   "Keeping the torso stationary, pull the handles back towards your torso while keeping the arms close to it until you touch the abdominals. Breathe out as you perform that movement. At that point you should be squeezing your back muscles hard. Hold that contraction for a second and slowly go back to the original position while breathing in."
  ]
 },
 "Wide-Grip_Lat_Pulldown": {
  "name": "Wide-Grip Lat Pulldown",
  "muscle": "lats",
  "level": "beginner",
  "steps": [
   "Sit down on a pull-down machine with a wide bar attached to the top pulley. Make sure that you adjust the knee pad of the machine to fit your height. These pads will prevent your body from being raised by the resistance attached to the bar.",
   "Grab the bar with the palms facing forward using the prescribed grip. Note on grips: For a wide grip, your hands need to be spaced out at a distance wider than shoulder width. For a medium grip, your hands need to be spaced out at a distance equal to your shoulder width and for a close grip at a distance smaller than your shoulder width.",
   "As you have both arms extended in front of you holding the bar at the chosen grip width, bring your torso back around 30 degrees or so while creating a curvature on your lower back and sticking your chest out. This is your starting position.",
   "As you breathe out, bring the bar down until it touches your upper chest by drawing the shoulders and the upper arms down and back. Tip: Concentrate on squeezing the back muscles once you reach the full contracted position. The upper torso should remain stationary and only the arms should move. The forearms should do no other work except for holding the bar; therefore do not try to pull down the bar using the forearms."
  ]
 },
 "Side_Lateral_Raise": {
  "name": "Side Lateral Raise",
  "muscle": "shoulders",
  "level": "beginner",
  "steps": [
   "Pick a couple of dumbbells and stand with a straight torso and the dumbbells by your side at arms length with the palms of the hand facing you. This will be your starting position.",
   "While maintaining the torso in a stationary position (no swinging), lift the dumbbells to your side with a slight bend on the elbow and the hands slightly tilted forward as if pouring water in a glass. Continue to go up until you arms are parallel to the floor. Exhale as you execute this movement and pause for a second at the top.",
   "Lower the dumbbells back down slowly to the starting position as you inhale.",
   "Repeat for the recommended amount of repetitions."
  ]
 },
 "Lateral_Raise_-_With_Bands": {
  "name": "Lateral Raise - With Bands",
  "muscle": "shoulders",
  "level": "beginner",
  "steps": [
   "To begin, stand on an exercise band so that tension begins at arm's length. Grasp the handles using a pronated (palms facing your thighs) grip that is slightly less than shoulder width. The handles should be resting on the sides of your thighs. Your arms should be extended with a slight bend at the elbows and your back should be straight. This will be your starting position.",
   "Use your side shoulders to lift the handles to the sides as you exhale. Continue to lift the handles until they are slightly above parallel. Tip: As you lift the handles, slightly tilt the hand as if you were pouring water and keep your arms extended. Also, keep your torso stationary and pause for a second at the top of the movement.",
   "Lower the handles back down slowly to the starting position. Inhale as you perform this portion of the movement.",
   "Repeat for the recommended amount of repetitions."
  ]
 },
 "Dumbbell_Shoulder_Press": {
  "name": "Dumbbell Shoulder Press",
  "muscle": "shoulders",
  "level": "intermediate",
  "steps": [
   "While holding a dumbbell in each hand, sit on a military press bench or utility bench that has back support. Place the dumbbells upright on top of your thighs.",
   "Now raise the dumbbells to shoulder height one at a time using your thighs to help propel them up into position.",
   "Make sure to rotate your wrists so that the palms of your hands are facing forward. This is your starting position.",
   "Now, exhale and push the dumbbells upward until they touch at the top."
  ]
 },
 "Shoulder_Press_-_With_Bands": {
  "name": "Shoulder Press - With Bands",
  "muscle": "shoulders",
  "level": "beginner",
  "steps": [
   "To begin, stand on an exercise band so that tension begins at arm's length. Grasp the handles and lift them so that the hands are at shoulder height at each side.",
   "Rotate the wrists so that the palms of your hands are facing forward. Your elbows should be bent, with the upper arms and forearms in line to the torso. This is your starting position.",
   "As you exhale, lift the handles up until your arms are fully extended overhead."
  ]
 },
 "Reverse_Flyes": {
  "name": "Reverse Flyes",
  "muscle": "shoulders",
  "level": "beginner",
  "steps": [
   "To begin, lie down on an incline bench with the chest and stomach pressing against the incline. Have the dumbbells in each hand with the palms facing each other (neutral grip).",
   "Extend the arms in front of you so that they are perpendicular to the angle of the bench. The legs should be stationary while applying pressure with the ball of your toes. This is the starting position.",
   "Maintaining the slight bend of the elbows, move the weights out and away from each other (to the side) in an arc motion while exhaling. Tip: Try to squeeze your shoulder blades together to get the best results from this exercise.",
   "The arms should be elevated until they are parallel to the floor."
  ]
 },
 "Push_Up_to_Side_Plank": {
  "name": "Push Up to Side Plank",
  "muscle": "chest",
  "level": "beginner",
  "steps": [
   "Get into pushup position on the toes with your hands just outside of shoulder width.",
   "Perform a pushup by allowing the elbows to flex. As you descend, keep your body straight.",
   "Do one pushup and as you come up, shift your weight on the left side of the body, twist to the side while bringing the right arm up towards the ceiling in a side plank.",
   "Lower the arm back to the floor for another pushup and then twist to the other side."
  ]
 },
 "Plank": {
  "name": "Plank",
  "muscle": "abdominals",
  "level": "beginner",
  "steps": [
   "Get into a prone position on the floor, supporting your weight on your toes and your forearms. Your arms are bent and directly below the shoulder.",
   "Keep your body straight at all times, and hold this position as long as possible. To increase difficulty, an arm or leg can be raised."
  ]
 },
 "Dumbbell_Bicep_Curl": {
  "name": "Dumbbell Bicep Curl",
  "muscle": "biceps",
  "level": "beginner",
  "steps": [
   "Stand up straight with a dumbbell in each hand at arm's length. Keep your elbows close to your torso and rotate the palms of your hands until they are facing forward. This will be your starting position.",
   "Now, keeping the upper arms stationary, exhale and curl the weights while contracting your biceps. Continue to raise the weights until your biceps are fully contracted and the dumbbells are at shoulder level. Hold the contracted position for a brief pause as you squeeze your biceps.",
   "Then, inhale and slowly begin to lower the dumbbells back to the starting position.",
   "Repeat for the recommended amount of repetitions."
  ]
 },
 "Hammer_Curls": {
  "name": "Hammer Curls",
  "muscle": "biceps",
  "level": "beginner",
  "steps": [
   "Stand up with your torso upright and a dumbbell on each hand being held at arms length. The elbows should be close to the torso.",
   "The palms of the hands should be facing your torso. This will be your starting position.",
   "Now, while holding your upper arm stationary, exhale and curl the weight forward while contracting the biceps. Continue to raise the weight until the biceps are fully contracted and the dumbbell is at shoulder level. Hold the contracted position for a brief moment as you squeeze the biceps. Tip: Focus on keeping the elbow stationary and only moving your forearm.",
   "After the brief pause, inhale and slowly begin the lower the dumbbells back down to the starting position."
  ]
 },
 "Dips_-_Triceps_Version": {
  "name": "Dips - Triceps Version",
  "muscle": "triceps",
  "level": "beginner",
  "steps": [
   "To get into the starting position, hold your body at arm's length with your arms nearly locked above the bars.",
   "Now, inhale and slowly lower yourself downward. Your torso should remain upright and your elbows should stay close to your body. This helps to better focus on tricep involvement. Lower yourself until there is a 90 degree angle formed between the upper arm and forearm.",
   "Then, exhale and push your torso back up using your triceps to bring your body back to the starting position.",
   "Repeat the movement for the prescribed amount of repetitions."
  ]
 },
 "Standing_Dumbbell_Triceps_Extension": {
  "name": "Standing Dumbbell Triceps Extension",
  "muscle": "triceps",
  "level": "beginner",
  "steps": [
   "To begin, stand up with a dumbbell held by both hands. Your feet should be about shoulder width apart from each other. Slowly use both hands to grab the dumbbell and lift it over your head until both arms are fully extended.",
   "The resistance should be resting in the palms of your hands with your thumbs around it. The palm of the hands should be facing up towards the ceiling. This will be your starting position.",
   "Keeping your upper arms close to your head with elbows in and perpendicular to the floor, lower the resistance in a semicircular motion behind your head until your forearms touch your biceps. Tip: The upper arms should remain stationary and only the forearms should move. Breathe in as you perform this step.",
   "Go back to the starting position by using the triceps to raise the dumbbell. Breathe out as you perform this step."
  ]
 },
 "Speed_Band_Overhead_Triceps": {
  "name": "Speed Band Overhead Triceps",
  "muscle": "triceps",
  "level": "beginner",
  "steps": [
   "For this exercise anchor a band to the ground. We used an incline bench and anchored the band to the base, standing over the bench. Alternatively, this could be performed standing on the band.",
   "To begin, pull the band behind your head, holding it with a pronated grip and your elbows up. This will be your starting position.",
   "To perform the movement, extend through the elbow to to straighten your arms, ensuring that you keep your upper arm in place.",
   "Pause, and then return to the starting position."
  ]
 },
 "Band_Skull_Crusher": {
  "name": "Band Skull Crusher",
  "muscle": "triceps",
  "level": "beginner",
  "steps": [
   "Secure a band to the base of a rack or the bench. Lay on the bench so that the band is lined up with your head.",
   "Take hold of the band, raising your elbows so that the upper arm is perpendicular to the floor. With the elbow flexed, the band should be above your head. This will be your starting position.",
   "Extend through the elbow to straighten your arm, keeping your upper arm in place. Pause at the top of the motion, and return to the starting position."
  ]
 },
 "Triceps_Pushdown": {
  "name": "Triceps Pushdown",
  "muscle": "triceps",
  "level": "beginner",
  "steps": [
   "Attach a straight or angled bar to a high pulley and grab with an overhand grip (palms facing down) at shoulder width.",
   "Standing upright with the torso straight and a very small inclination forward, bring the upper arms close to your body and perpendicular to the floor. The forearms should be pointing up towards the pulley as they hold the bar. This is your starting position.",
   "Using the triceps, bring the bar down until it touches the front of your thighs and the arms are fully extended perpendicular to the floor. The upper arms should always remain stationary next to your torso and only the forearms should move. Exhale as you perform this movement.",
   "After a second hold at the contracted position, bring the bar slowly up to the starting point. Breathe in as you perform this step."
  ]
 },
 "Machine_Bicep_Curl": {
  "name": "Machine Bicep Curl",
  "muscle": "biceps",
  "level": "beginner",
  "steps": [
   "Adjust the seat to the appropriate height and make your weight selection. Place your upper arms against the pads and grasp the handles. This will be your starting position.",
   "Perform the movement by flexing the elbow, pulling your lower arm towards your upper arm.",
   "Pause at the top of the movement, and then slowly return the weight to the starting position.",
   "Avoid returning the weight all the way to the stops until the set is complete to keep tension on the muscles being worked."
  ]
 },
 "Dead_Bug": {
  "name": "Dead Bug",
  "muscle": "abdominals",
  "level": "beginner",
  "steps": [
   "Begin lying on your back with your hands extended above you toward the ceiling.",
   "Bring your feet, knees, and hips up to 90 degrees.",
   "Exhale hard to bring your ribcage down and flatten your back onto the floor, rotating your pelvis up and squeezing your glutes. Hold this position throughout the movement. This will be your starting position.",
   "Initiate the exercise by extending one leg, straightening the knee and hip to bring the leg just above the ground."
  ]
 },
 "Crunches": {
  "name": "Crunches",
  "muscle": "abdominals",
  "level": "beginner",
  "steps": [
   "Lie flat on your back with your feet flat on the ground, or resting on a bench with your knees bent at a 90 degree angle. If you are resting your feet on a bench, place them three to four inches apart and point your toes inward so they touch.",
   "Now place your hands lightly on either side of your head keeping your elbows in. Tip: Don't lock your fingers behind your head.",
   "While pushing the small of your back down in the floor to better isolate your abdominal muscles, begin to roll your shoulders off the floor.",
   "Continue to push down as hard as you can with your lower back as you contract your abdominals and exhale. Your shoulders should come up off the floor only about four inches, and your lower back should remain on the floor. At the top of the movement, contract your abdominals hard and keep the contraction for a second. Tip: Focus on slow, controlled movement - don't cheat yourself by using momentum."
  ]
 },
 "Reverse_Crunch": {
  "name": "Reverse Crunch",
  "muscle": "abdominals",
  "level": "beginner",
  "steps": [
   "Lie down on the floor with your legs fully extended and arms to the side of your torso with the palms on the floor. Your arms should be stationary for the entire exercise.",
   "Move your legs up so that your thighs are perpendicular to the floor and feet are together and parallel to the floor. This is the starting position.",
   "While inhaling, move your legs towards the torso as you roll your pelvis backwards and you raise your hips off the floor. At the end of this movement your knees will be touching your chest.",
   "Hold the contraction for a second and move your legs back to the starting position while exhaling."
  ]
 },
 "Russian_Twist": {
  "name": "Russian Twist",
  "muscle": "abdominals",
  "level": "intermediate",
  "steps": [
   "Lie down on the floor placing your feet either under something that will not move or by having a partner hold them. Your legs should be bent at the knees.",
   "Elevate your upper body so that it creates an imaginary V-shape with your thighs. Your arms should be fully extended in front of you perpendicular to your torso and with the hands clasped. This is the starting position.",
   "Twist your torso to the right side until your arms are parallel with the floor while breathing out.",
   "Hold the contraction for a second and move back to the starting position while breathing out. Now move to the opposite side performing the same techniques you applied to the right side."
  ]
 },
 "Side_Bridge": {
  "name": "Side Bridge",
  "muscle": "abdominals",
  "level": "beginner",
  "steps": []
 },
 "Flutter_Kicks": {
  "name": "Flutter Kicks",
  "muscle": "glutes",
  "level": "beginner",
  "steps": [
   "On a flat bench lie facedown with the hips on the edge of the bench, the legs straight with toes high off the floor and with the arms on top of the bench holding on to the front edge.",
   "Squeeze your glutes and hamstrings and straighten the legs until they are level with the hips. This will be your starting position.",
   "Start the movement by lifting the left leg higher than the right leg.",
   "Then lower the left leg as you lift the right leg."
  ]
 },
 "Mountain_Climbers": {
  "name": "Mountain Climbers",
  "muscle": "quadriceps",
  "level": "beginner",
  "steps": [
   "Begin in a pushup position, with your weight supported by your hands and toes. Flexing the knee and hip, bring one leg until the knee is approximately under the hip. This will be your starting position.",
   "Explosively reverse the positions of your legs, extending the bent leg until the leg is straight and supported by the toe, and bringing the other foot up with the hip and knee flexed. Repeat in an alternating fashion for 20-30 seconds."
  ]
 },
 "Cable_Crunch": {
  "name": "Cable Crunch",
  "muscle": "abdominals",
  "level": "beginner",
  "steps": [
   "Kneel below a high pulley that contains a rope attachment.",
   "Grasp cable rope attachment and lower the rope until your hands are placed next to your face.",
   "Flex your hips slightly and allow the weight to hyperextend the lower back. This will be your starting position.",
   "With the hips stationary, flex the waist as you contract the abs so that the elbows travel towards the middle of the thighs. Exhale as you perform this portion of the movement and hold the contraction for a second."
  ]
 },
 "Dumbbell_Side_Bend": {
  "name": "Dumbbell Side Bend",
  "muscle": "abdominals",
  "level": "beginner",
  "steps": [
   "Stand up straight while holding a dumbbell on the left hand (palms facing the torso) as you have the right hand holding your waist. Your feet should be placed at shoulder width. This will be your starting position.",
   "While keeping your back straight and your head up, bend only at the waist to the right as far as possible. Breathe in as you bend to the side. Then hold for a second and come back up to the starting position as you exhale. Tip: Keep the rest of the body stationary.",
   "Now repeat the movement but bending to the left instead. Hold for a second and come back to the starting position.",
   "Repeat for the recommended amount of repetitions and then change hands."
  ]
 },
 "Bodyweight_Squat": {
  "name": "Bodyweight Squat",
  "muscle": "quadriceps",
  "level": "beginner",
  "steps": [
   "Stand with your feet shoulder width apart. You can place your hands behind your head. This will be your starting position.",
   "Begin the movement by flexing your knees and hips, sitting back with your hips.",
   "Continue down to full depth if you are able,and quickly reverse the motion until you return to the starting position. As you squat, keep your head and chest up and push your knees out."
  ]
 },
 "Dumbbell_Lunges": {
  "name": "Dumbbell Lunges",
  "muscle": "quadriceps",
  "level": "beginner",
  "steps": [
   "Stand with your torso upright holding two dumbbells in your hands by your sides. This will be your starting position.",
   "Step forward with your right leg around 2 feet or so from the foot being left stationary behind and lower your upper body down, while keeping the torso upright and maintaining balance. Inhale as you go down. Note: As in the other exercises, do not allow your knee to go forward beyond your toes as you come down, as this will put undue stress on the knee joint. Make sure that you keep your front shin perpendicular to the ground.",
   "Using mainly the heel of your foot, push up and go back to the starting position as you exhale.",
   "Repeat the movement for the recommended amount of repetitions and then perform with the left leg."
  ]
 },
 "Bodyweight_Walking_Lunge": {
  "name": "Bodyweight Walking Lunge",
  "muscle": "quadriceps",
  "level": "beginner",
  "steps": [
   "Begin standing with your feet shoulder width apart and your hands on your hips.",
   "Step forward with one leg, flexing the knees to drop your hips. Descend until your rear knee nearly touches the ground. Your posture should remain upright, and your front knee should stay above the front foot.",
   "Drive through the heel of your lead foot and extend both knees to raise yourself back up.",
   "Step forward with your rear foot, repeating the lunge on the opposite leg."
  ]
 },
 "Step-up_with_Knee_Raise": {
  "name": "Step-up with Knee Raise",
  "muscle": "glutes",
  "level": "beginner",
  "steps": [
   "Stand facing a box or bench of an appropriate height with your feet together. This will be your starting position.",
   "Begin the movement by stepping up, putting your left foot on the top of the bench. Extend through the hip and knee of your front leg to stand up on the box. As you stand on the box with your left leg, flex your right knee and hip, bringing your knee as high as you can.",
   "Reverse this motion to step down off the box, and then repeat the sequence on the opposite leg."
  ]
 },
 "Squats_-_With_Bands": {
  "name": "Squats - With Bands",
  "muscle": "quadriceps",
  "level": "beginner",
  "steps": [
   "To start out, make sure that the exercise band is at an even split between both the left and right side of the body. To do this, use your hands to grab both sides of the band and place both feet in the middle of the band. Your feet should be shoulder width apart from each other.",
   "When holding the bands, they should be the same height on each side. You should be using a pronated grip (palms facing forward) and have the handles of the bands next to your face for this exercise. This is the starting position.",
   "Slowly start to bend the knees and lower the legs so that your thighs are parallel to the floor while exhaling.",
   "Use the heel of your feet to push your body up to the starting position as you exhale."
  ]
 },
 "Dumbbell_Step_Ups": {
  "name": "Dumbbell Step Ups",
  "muscle": "quadriceps",
  "level": "intermediate",
  "steps": [
   "Stand up straight while holding a dumbbell on each hand (palms facing the side of your legs).",
   "Place the right foot on the elevated platform. Step on the platform by extending the hip and the knee of your right leg. Use the heel mainly to lift the rest of your body up and place the foot of the left leg on the platform as well. Breathe out as you execute the force required to come up.",
   "Step down with the left leg by flexing the hip and knee of the right leg as you inhale. Return to the original standing position by placing the right foot of to next to the left foot on the initial position.",
   "Repeat with the right leg for the recommended amount of repetitions and then perform with the left leg."
  ]
 },
 "Stiff-Legged_Dumbbell_Deadlift": {
  "name": "Stiff-Legged Dumbbell Deadlift",
  "muscle": "hamstrings",
  "level": "beginner",
  "steps": [
   "Grasp a couple of dumbbells holding them by your side at arm's length.",
   "Stand with your torso straight and your legs spaced using a shoulder width or narrower stance. The knees should be slightly bent. This is your starting position.",
   "Keeping the knees stationary, lower the dumbbells to over the top of your feet by bending at the waist while keeping your back straight. Keep moving forward as if you were going to pick something from the floor until you feel a stretch on the hamstrings. Exhale as you perform this movement",
   "Start bringing your torso up straight again by extending your hips and waist until you are back at the starting position. Inhale as you perform this movement."
  ]
 },
 "Leg_Press": {
  "name": "Leg Press",
  "muscle": "quadriceps",
  "level": "beginner",
  "steps": [
   "Using a leg press machine, sit down on the machine and place your legs on the platform directly in front of you at a medium (shoulder width) foot stance. (Note: For the purposes of this discussion we will use the medium stance described above which targets overall development; however you can choose any of the three stances described in the foot positioning section).",
   "Lower the safety bars holding the weighted platform in place and press the platform all the way up until your legs are fully extended in front of you. Tip: Make sure that you do not lock your knees. Your torso and the legs should make a perfect 90-degree angle. This will be your starting position.",
   "As you inhale, slowly lower the platform until your upper and lower legs make a 90-degree angle.",
   "Pushing mainly with the heels of your feet and using the quadriceps go back to the starting position as you exhale."
  ]
 },
 "Leg_Extensions": {
  "name": "Leg Extensions",
  "muscle": "quadriceps",
  "level": "beginner",
  "steps": [
   "For this exercise you will need to use a leg extension machine. First choose your weight and sit on the machine with your legs under the pad (feet pointed forward) and the hands holding the side bars. This will be your starting position. Tip: You will need to adjust the pad so that it falls on top of your lower leg (just above your feet). Also, make sure that your legs form a 90-degree angle between the lower and upper leg. If the angle is less than 90-degrees then that means the knee is over the toes which in turn creates undue stress at the knee joint. If the machine is designed that way, either look for another machine or just make sure that when you start executing the exercise you stop going down once you hit the 90-degree angle.",
   "Using your quadriceps, extend your legs to the maximum as you exhale. Ensure that the rest of the body remains stationary on the seat. Pause a second on the contracted position.",
   "Slowly lower the weight back to the original position as you inhale, ensuring that you do not go past the 90-degree angle limit.",
   "Repeat for the recommended amount of times."
  ]
 },
 "Seated_Leg_Curl": {
  "name": "Seated Leg Curl",
  "muscle": "hamstrings",
  "level": "beginner",
  "steps": [
   "Adjust the machine lever to fit your height and sit on the machine with your back against the back support pad.",
   "Place the back of lower leg on top of padded lever (just a few inches under the calves) and secure the lap pad against your thighs, just above the knees. Then grasp the side handles on the machine as you point your toes straight (or you can also use any of the other two stances) and ensure that the legs are fully straight right in front of you. This will be your starting position.",
   "As you exhale, pull the machine lever as far as possible to the back of your thighs by flexing at the knees. Keep your torso stationary at all times. Hold the contracted position for a second.",
   "Slowly return to the starting position as you breathe in."
  ]
 },
 "Calf_Raises_-_With_Bands": {
  "name": "Calf Raises - With Bands",
  "muscle": "calves",
  "level": "beginner",
  "steps": [
   "Grab an exercise band and stand on it with your toes making sure that the length of the band between the foot and the arms is the same for both sides.",
   "While holding the handles of the band, raise the arms to the side of your head as if you were getting ready to perform a shoulder press. The palms should be facing forward with the elbows bent and to the sides. This movement will create tension on the band. This will be your starting position.",
   "Keeping the hands by your shoulder, stand up on your toes as you exhale and contract the calves hard at the top of the movement.",
   "After a one second contraction, slowly go back down to the starting position."
  ]
 },
 "Standing_Dumbbell_Calf_Raise": {
  "name": "Standing Dumbbell Calf Raise",
  "muscle": "calves",
  "level": "intermediate",
  "steps": [
   "Stand with your torso upright holding two dumbbells in your hands by your sides. Place the ball of the foot on a sturdy and stable wooden board (that is around 2-3 inches tall) while your heels extend off and touch the floor. This will be your starting position.",
   "With the toes pointing either straight (to hit all parts equally), inwards (for emphasis on the outer head) or outwards (for emphasis on the inner head), raise the heels off the floor as you exhale by contracting the calves. Hold the top contraction for a second.",
   "As you inhale, go back to the starting position by slowly lowering the heels.",
   "Repeat for the recommended amount of times."
  ]
 },
 "Butt_Lift_Bridge": {
  "name": "Butt Lift (Bridge)",
  "muscle": "glutes",
  "level": "beginner",
  "steps": [
   "Lie flat on the floor on your back with the hands by your side and your knees bent. Your feet should be placed around shoulder width. This will be your starting position.",
   "Pushing mainly with your heels, lift your hips off the floor while keeping your back straight. Breathe out as you perform this part of the motion and hold at the top for a second.",
   "Slowly go back to the starting position as you breathe in."
  ]
 },
 "Single_Leg_Glute_Bridge": {
  "name": "Single Leg Glute Bridge",
  "muscle": "glutes",
  "level": "beginner",
  "steps": [
   "Lay on the floor with your feet flat and knees bent.",
   "Raise one leg off of the ground, pulling the knee to your chest. This will be your starting position.",
   "Execute the movement by driving through the heel, extending your hip upward and raising your glutes off of the ground.",
   "Extend as far as possible, pause and then return to the starting position."
  ]
 },
 "Hip_Extension_with_Bands": {
  "name": "Hip Extension with Bands",
  "muscle": "glutes",
  "level": "beginner",
  "steps": [
   "Secure one end of the band to the lower portion of a post and attach the other to one ankle.",
   "Facing the attachment point of the band, hold on to the column to stabilize yourself.",
   "Keeping your head and your chest up, move the resisted leg back as far as you can while keeping the knee straight.",
   "Return the leg to the starting position."
  ]
 },
 "Barbell_Hip_Thrust": {
  "name": "Barbell Hip Thrust",
  "muscle": "glutes",
  "level": "intermediate",
  "steps": [
   "Begin seated on the ground with a bench directly behind you. Have a loaded barbell over your legs. Using a fat bar or having a pad on the bar can greatly reduce the discomfort caused by this exercise.",
   "Roll the bar so that it is directly above your hips, and lean back against the bench so that your shoulder blades are near the top of it.",
   "Begin the movement by driving through your feet, extending your hips vertically through the bar. Your weight should be supported by your shoulder blades and your feet. Extend as far as possible, then reverse the motion to return to the starting position."
  ]
 },
 "Star_Jump": {
  "name": "Star Jump",
  "muscle": "quadriceps",
  "level": "beginner",
  "steps": [
   "Begin in a relaxed stance with your feet shoulder width apart and hold your arms close to the body.",
   "To initiate the move, squat down halfway and explode back up as high as possible. Fully extend your entire body, spreading your legs and arms away from the body.",
   "As you land, bring your limbs back in and absorb your impact through the legs."
  ]
 },
 "Trail_Running_Walking": {
  "name": "Trail Running/Walking",
  "muscle": "quadriceps",
  "level": "beginner",
  "steps": [
   "Running or hiking on trails will get the blood pumping and heart beating almost immediately. Make sure you have good shoes. While you use the muscles in your calves and buttocks to pull yourself up a hill, the knees, joints and ankles absorb the bulk of the pounding coming back down. Take smaller steps as you walk downhill, keep your knees bent to reduce the impact and slow down to avoid falling.",
   "A 150 lb person can burn over 200 calories for 30 minutes walking uphill, compared to 175 on a flat surface. If running the trail, a 150 lb person can burn well over 500 calories in 30 minutes."
  ]
 },
 "Walking_Treadmill": {
  "name": "Walking, Treadmill",
  "muscle": "quadriceps",
  "level": "beginner",
  "steps": [
   "To begin, step onto the treadmill and select the desired option from the menu. Most treadmills have a manual setting, or you can select a program to run. Typically, you can enter your age and weight to estimate the amount of calories burned during exercise. Elevation can be adjusted to change the intensity of the workout.",
   "Treadmills offer convenience, cardiovascular benefits, and usually have less impact than walking outside. When walking, you should move at a moderate to fast pace, not a leisurely one. Being an activity of lower intensity, walking doesn't burn as many calories as some other activities, but still provides great benefit. A 150 lb person will burn about 175 calories walking 4 miles per hour for 30 minutes, compared to 450 calories running twice as fast. Maintain proper posture as you walk, and only hold onto the handles when necessary, such as when dismounting or checking your heart rate."
  ]
 },
 "Cat_Stretch": {
  "name": "Cat Stretch",
  "muscle": "lower back",
  "level": "beginner",
  "steps": [
   "Position yourself on the floor on your hands and knees.",
   "Pull your belly in and round your spine, lower back, shoulders, and neck, letting your head drop.",
   "Hold for 15 seconds."
  ]
 },
 "Standing_Hip_Circles": {
  "name": "Standing Hip Circles",
  "muscle": "abductors",
  "level": "beginner",
  "steps": [
   "Begin standing on one leg, holding to a vertical support.",
   "Raise the unsupported knee to 90 degrees. This will be your starting position.",
   "Open the hip as far as possible, attempting to make a big circle with your knee.",
   "Perform this movement slowly for a number of repetitions, and repeat on the other side."
  ]
 },
 "Round_The_World_Shoulder_Stretch": {
  "name": "Round The World Shoulder Stretch",
  "muscle": "shoulders",
  "level": "beginner",
  "steps": [
   "Stand up straight with your legs together, holding a bodybar or broomstick.",
   "Hold the pole behind your hips with a wider than shoulder width grip. Your palms should be down and your thumbs facing out.",
   "Slowly lift your arms up behind your head. Don't force it if it gets hard to lift further."
  ]
 },
 "Chin_To_Chest_Stretch": {
  "name": "Chin To Chest Stretch",
  "muscle": "neck",
  "level": "beginner",
  "steps": [
   "Get into a seated position on the floor.",
   "Place both hands at the rear of your head, fingers interlocked, thumbs pointing down and elbows pointing straight ahead. Slowly pull your head down to your chest. Hold for 20-30 seconds."
  ]
 },
 "Calf_Stretch_Hands_Against_Wall": {
  "name": "Calf Stretch Hands Against Wall",
  "muscle": "calves",
  "level": "beginner",
  "steps": [
   "Stand facing a wall from several feet away. Stagger your stance, placing one foot forward.",
   "Lean forward and rest your hands on the wall, keeping your heel, hip and head in a straight line.",
   "Attempt to keep your heel on the ground. Hold for 10-20 seconds and then switch sides."
  ]
 },
 "Kneeling_Hip_Flexor": {
  "name": "Kneeling Hip Flexor",
  "muscle": "quadriceps",
  "level": "beginner",
  "steps": [
   "Kneel on a mat and bring your right knee up so the bottom of your foot is on the floor and extend your left leg out behind you so the top of your foot is on the floor.",
   "Shift your weight forward until you feel a stretch in your hip. Hold for 15 seconds, then repeat for your other side."
  ]
 },
 "Triceps_Stretch": {
  "name": "Triceps Stretch",
  "muscle": "triceps",
  "level": "beginner",
  "steps": [
   "Reach your hand behind your head, grasp your elbow and gently pull. Hold for 10 to 20 seconds, then switch sides."
  ]
 },
 "Chest_And_Front_Of_Shoulder_Stretch": {
  "name": "Chest And Front Of Shoulder Stretch",
  "muscle": "chest",
  "level": "beginner",
  "steps": [
   "Start off by standing with your legs together, holding a bodybar or a broomstick.",
   "Take a slightly wider than shoulder width grip on the pole and hold it in front of you with your palms facing down.",
   "Carefully lift the pole up and behind your head."
  ]
 },
 "Standing_Hamstring_and_Calf_Stretch": {
  "name": "Standing Hamstring and Calf Stretch",
  "muscle": "hamstrings",
  "level": "beginner",
  "steps": [
   "Being by looping a belt, band, or rope around one foot. While standing, place that foot forward.",
   "Bend your back leg, while keeping the front one straight. Now raise the toes of your front foot off of the ground and lean forward.",
   "Using the belt, pull on the top of the foot to increase the stretch in the calf. Hold for 10-20 seconds and repeat with the other foot."
  ]
 },
 "All_Fours_Quad_Stretch": {
  "name": "All Fours Quad Stretch",
  "muscle": "quadriceps",
  "level": "intermediate",
  "steps": [
   "Start off on your hands and knees, then lift your leg off the floor and hold the foot with your hand.",
   "Use your hand to hold the foot or ankle, keeping the knee fully flexed, stretching the quadriceps and hip flexors.",
   "Focus on extending your hips, thrusting them towards the floor. Hold for 10-20 seconds and then switch sides."
  ]
 },
 "Alternate_Hammer_Curl": {
  "name": "Alternate Hammer Curl",
  "muscle": "biceps",
  "level": "beginner",
  "steps": [
   "Stand up with your torso upright and a dumbbell in each hand being held at arms length. The elbows should be close to the torso.",
   "The palms of the hands should be facing your torso. This will be your starting position.",
   "While holding the upper arm stationary, curl the right weight forward while contracting the biceps as you breathe out. Continue the movement until your biceps is fully contracted and the dumbbells are at shoulder level. Hold the contracted position for a second as you squeeze the biceps. Tip: Only the forearms should move.",
   "Slowly begin to bring the dumbbells back to starting position as your breathe in."
  ]
 },
 "Arm_Circles": {
  "name": "Arm Circles",
  "muscle": "shoulders",
  "level": "beginner",
  "steps": [
   "Stand up and extend your arms straight out by the sides. The arms should be parallel to the floor and perpendicular (90-degree angle) to your torso. This will be your starting position.",
   "Slowly start to make circles of about 1 foot in diameter with each outstretched arm. Breathe normally as you perform the movement.",
   "Continue the circular motion of the outstretched arms for about ten seconds. Then reverse the movement, going the opposite direction."
  ]
 },
 "Childs_Pose": {
  "name": "Child's Pose",
  "muscle": "lower back",
  "level": "beginner",
  "steps": [
   "Get on your hands and knees, walk your hands in front of you.",
   "Lower your buttocks down to sit on your heels. Let your arms drag along the floor as you sit back to stretch your entire spine.",
   "Once you settle onto your heels, bring your hands next to your feet and relax. \"breathe\" into your back. Rest your forehead on the floor. Avoid this position if you have knee problems."
  ]
 },
 "Dumbbell_Squat": {
  "name": "Dumbbell Squat",
  "muscle": "quadriceps",
  "level": "beginner",
  "steps": [
   "Stand up straight while holding a dumbbell on each hand (palms facing the side of your legs).",
   "Position your legs using a shoulder width medium stance with the toes slightly pointed out. Keep your head up at all times as looking down will get you off balance and also maintain a straight back. This will be your starting position. Note: For the purposes of this discussion we will use the medium stance described above which targets overall development; however you can choose any of the three stances discussed in the foot stances section.",
   "Begin to slowly lower your torso by bending the knees as you maintain a straight posture with the head up. Continue down until your thighs are parallel to the floor. Tip: If you performed the exercise correctly, the front of the knees should make an imaginary straight line with the toes that is perpendicular to the front. If your knees are past that imaginary line (if they are past your toes) then you are placing undue stress on the knee and the exercise has been performed incorrectly.",
   "Begin to raise your torso as you exhale by pushing the floor with the heel of your foot mainly as you straighten the legs again and go back to the starting position."
  ]
 },
 "Double_Leg_Butt_Kick": {
  "name": "Double Leg Butt Kick",
  "muscle": "quadriceps",
  "level": "beginner",
  "steps": [
   "Begin standing with your knees slightly bent.",
   "Quickly squat a short distance, flexing the hips and knees, and immediately extend to jump for maximum vertical height.",
   "As you go up, tuck your heels by flexing the knees, attempting to touch the buttocks.",
   "Finish the motion by landing with the knees only partially bent, using your legs to absorb the impact."
  ]
 },
 "Incline_Push-Up_Wide": {
  "name": "Incline Push-Up Wide",
  "muscle": "chest",
  "level": "beginner",
  "steps": [
   "Stand facing a Smith machine bar or sturdy elevated platform at an appropriate height.",
   "Place your hands on the bar, with your hands wider than shoulder width.",
   "Position your feet back from the bar with arms and body straight. Your arms should be perpendicular to the body. This will be your starting position.",
   "Keeping your body straight, lower your chest to the bar by bending the arms."
  ]
 }
};
