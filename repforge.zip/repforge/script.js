const $ = id => document.getElementById(id);
const form = $("planForm");
const results = $("results");
let currentPanel = 1;
const foodProtein = {
 eggs:{label:"Eggs (2)",protein:12}, milk:{label:"Milk (1 glass)",protein:8}, curd:{label:"Curd / yoghurt (1 bowl)",protein:6},
 dal:{label:"Dal (1 bowl)",protein:9}, paneer:{label:"Paneer (100 g)",protein:18}, tofu:{label:"Tofu (100 g)",protein:12},
 chicken:{label:"Chicken (100 g cooked)",protein:27}, fish:{label:"Fish (100 g cooked)",protein:22}, chana:{label:"Chana / beans (1 bowl)",protein:9},
 soy:{label:"Soy chunks (25 g dry)",protein:13}, roti:{label:"Roti (1 medium)",protein:3}, rice:{label:"Cooked rice (1 cup)",protein:4},
 oats:{label:"Oats (40 g dry)",protein:5}, nuts:{label:"Nuts/seeds (small handful)",protein:5}, bread:{label:"Bread (2 slices)",protein:6}
};
const meals = {
 veg:{breakfast:["Poha/upma with vegetables and curd","Oats with milk or fortified soy milk and fruit","Besan chilla with curd"],lunch:["Roti/rice, dal or beans, sabzi and curd","Vegetable khichdi with dal and curd","Paneer/tofu with roti and vegetables"],snack:["Fruit with roasted chana","Curd/yoghurt and fruit","Milk or fortified soy milk with a snack"],dinner:["Dal, roti/rice and cooked vegetables","Paneer/tofu bhurji with roti","Idli/dosa with sambar"]},
 eggetarian:{breakfast:["Eggs with toast or roti and fruit","Poha with curd","Oats with milk and fruit"],lunch:["Roti/rice, dal, sabzi and eggs or curd","Egg bhurji with roti and vegetables","Rajma/chole bowl with rice and curd"],snack:["Fruit with roasted chana","Boiled egg and fruit","Curd/yoghurt with fruit"],dinner:["Egg curry with roti/rice and vegetables","Dal, rice and cooked vegetables","Idli/dosa with sambar"]},
 mixed:{breakfast:["Eggs with toast/roti and fruit","Poha/upma with curd","Oats with milk and fruit"],lunch:["Rice/roti, dal, vegetables and chicken/fish or beans","Chicken/soy/paneer bowl with rice and vegetables","Rajma/chole with rice and curd"],snack:["Fruit and yoghurt","Roasted chana","Egg or suitable dairy/soy snack"],dinner:["Chicken/fish/tofu with roti/rice and vegetables","Dal, rice and cooked vegetables","Egg curry with roti and vegetables"]},
 vegan:{breakfast:["Poha/upma with vegetables and roasted chana","Oats with fortified soy milk, fruit and seeds","Besan chilla"],lunch:["Roti/rice, dal/beans and sabzi","Tofu with roti and vegetables","Vegetable khichdi with dal"],snack:["Fruit with roasted chana","Hummus with bread/vegetables","Soy yoghurt or fortified plant milk with fruit"],dinner:["Dal, roti/rice and vegetables","Tofu/bean curry with rice","Idli/dosa with sambar"]}
};
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function getFoodRows(){return [...document.querySelectorAll(".log-row")];}
function rowProtein(row){const key=row.querySelector(".log-food").value;return foodProtein[key].protein*Number(row.querySelector(".portion-value").textContent);}
function updateFoodLog(){
 let total=0;
 getFoodRows().forEach(row=>{
  const key=row.querySelector(".log-food").value;
  const qty=Number(row.querySelector(".portion-value").textContent);
  const grams=foodProtein[key].protein*qty;total+=grams;
  row.querySelector(".protein-value").textContent=grams+" g";
  row.querySelector(".portion-minus").disabled=qty<=1;
 });
 $("proteinTotal").textContent="ESTIMATED PROTEIN: "+total+" g";
}
function bindRow(row){
 row.querySelector(".log-food").addEventListener("change",updateFoodLog);
 row.querySelector(".portion-minus").addEventListener("click",()=>{const n=row.querySelector(".portion-value");n.textContent=Math.max(1,Number(n.textContent)-1);updateFoodLog();});
 row.querySelector(".portion-plus").addEventListener("click",()=>{const n=row.querySelector(".portion-value");n.textContent=Math.min(8,Number(n.textContent)+1);updateFoodLog();});
 row.querySelector(".remove-food").addEventListener("click",()=>{if(getFoodRows().length>1){row.remove();updateFoodLog();}});
}
// Keep Full body mutually exclusive with individual target areas.
document.querySelectorAll('input[name="target"]').forEach(input=>input.addEventListener("change",()=>{
 const full=document.querySelector('input[name="target"][value="full"]');
 const others=[...document.querySelectorAll('input[name="target"]')].filter(el=>el.value!=="full");
 if(input.value==="full"&&input.checked)others.forEach(el=>el.checked=false);
 if(input.value!=="full"&&input.checked)full.checked=false;
 if(![...document.querySelectorAll('input[name="target"]:checked')].length)full.checked=true;
}));
getFoodRows().forEach(bindRow);
$("addFood").addEventListener("click",()=>{
 if(getFoodRows().length>=12)return;
 const row=document.createElement("div");row.className="log-row";
 row.innerHTML=`<select class="log-food" aria-label="Food item">${Object.entries(foodProtein).map(([k,v])=>`<option value="${k}">${esc(v.label)}</option>`).join("")}</select><div class="portion-control"><button type="button" class="portion-minus" aria-label="Decrease portion">−</button><span class="portion-value">1</span><button type="button" class="portion-plus" aria-label="Increase portion">+</button></div><span class="protein-value">0 g</span><button type="button" class="remove-food" aria-label="Remove food">×</button>`;
 $("foodLog").appendChild(row);bindRow(row);updateFoodLog();
});
function setPanel(n){
 currentPanel=n;
 document.querySelectorAll(".form-panel").forEach(p=>p.classList.toggle("hidden",Number(p.dataset.panel)!==n));
 $("progressBar").style.width=(n*25)+"%";
 const names={1:"ABOUT YOU",2:"TRAINING",3:"NUTRITION",4:"REVIEW"};
 $("progressText").innerHTML=`0${n} <b>/</b> 04 — ${names[n]}`;
 document.querySelectorAll(".rail-step").forEach((step,i)=>step.classList.toggle("active",i===n-1));
 if(n===4)buildReview();
 $("planForm").scrollIntoView({behavior:"smooth",block:"start"});
}
document.querySelectorAll("[data-next]").forEach(b=>b.addEventListener("click",()=>{
 if(!validatePanel(currentPanel))return;
 setPanel(Number(b.dataset.next));
}));
document.querySelectorAll("[data-back]").forEach(b=>b.addEventListener("click",()=>setPanel(Number(b.dataset.back))));
function validatePanel(n){
 const panel=document.querySelector(`[data-panel="${n}"]`);
 for(const el of panel.querySelectorAll("input[required],select[required]")){
  if(el.type==="radio")continue;
  if(!el.checkValidity()){el.reportValidity();el.focus();return false;}
 }
 if(n===1){
  const age=Number($("age").value),h=Number($("height").value),w=Number($("weight").value);
  if(age<10||age>100||h<100||h>230||w<25||w>300){alert("Please check the age, height and weight entries.");return false;}
  if(!$("sex").value){$("sex").focus();$("sex").reportValidity();return false;}
 }
 return true;
}
function getData(){
 return {name:$("name").value.trim(),age:Number($("age").value),height:Number($("height").value),weight:Number($("weight").value),sex:$("sex").value,activity:$("activity").value,goal:document.querySelector('input[name="goal"]:checked').value,level:$("level").value,days:Number($("days").value),targets:[...document.querySelectorAll('input[name="target"]:checked')].map(el=>el.value),place:$("place").value,equipment:$("equipment").value,duration:$("duration").value,time:$("time").value,limits:$("limits").value,food:$("food").value,cooking:$("cooking").value,mealCount:$("mealCount").value,allergies:$("allergies").value.trim()};
}
function labelFor(id){const el=$(id);return el.options?el.options[el.selectedIndex].text:el.value;}
function buildReview(){
 const d=getData();const goalNames={strength:"Strength",fitness:"Fitness",mobility:"Mobility",energy:"Daily energy"};
 const items=[
 ["YOUR PROFILE",`${d.age} years · ${d.height} cm · ${d.weight} kg`,"Personal details are used for context, not to judge your body."],
 ["MOVEMENT",`${goalNames[d.goal]} · ${d.days} days/week`,`${labelFor("place")} · ${labelFor("equipment")} · ${labelFor("duration")} · Targets: ${d.targets.map(t=>({full:"Full body",chest:"Chest",back:"Back",shoulders:"Shoulders",arms:"Arms",core:"Core",legs:"Legs",glutes:"Glutes",cardio:"Cardio",mobility:"Mobility"})[t]||t).join(", ")}`],
 ["FOOD STYLE",labelFor("food"),`${labelFor("cooking")} · ${labelFor("mealCount")}`],
 ["DAILY FOOD LOG",`${getFoodRows().reduce((s,r)=>s+rowProtein(r),0)} g estimated protein`,`${getFoodRows().length} food item types entered. Rough estimates only.`]
 ];
 $("reviewCard").innerHTML=items.map(x=>`<div class="review-item"><small>${esc(x[0])}</small><strong>${esc(x[1])}</strong><p>${esc(x[2])}</p></div>`).join("");
}
function calcEnergy(d){
 if(d.age<18||d.sex==="unsure")return null;
 // Mifflin-St Jeor estimate is intended for adults; label it clearly as rough and not a diet target.
 const bmr=10*d.weight+6.25*d.height-5*d.age+(d.sex==="male"?5:-161);
 const factors={low:1.2,light:1.375,moderate:1.55,high:1.725};
 return Math.round(bmr*factors[d.activity]/50)*50;
}
/* ===== REPFORGE: exercise library (photos come from images/<db>/0.jpg + 1.jpg) ===== */
const ALL = ["none","dumbbells","bands","gym"];
const DUMB = ["dumbbells","gym"];
// ex(db, name, type, equipment, level 0-2, high-impact?)
const ex = (db,name,type="reps",eq=ALL,lv=0,hi=false)=>({db,name,type,eq,lv,hi});
const LIB = {
 chest:[ex("Incline_Push-Up","Incline Push-Up (hands on wall or bench)"),ex("Pushups","Push-Up","reps",ALL,1),ex("Push-Up_Wide","Wide Push-Up","reps",ALL,2),ex("Dumbbell_Bench_Press","Dumbbell Bench Press","reps",DUMB),ex("Bench_Press_-_With_Bands","Band Chest Press","reps",["bands"]),ex("Machine_Bench_Press","Machine Chest Press","reps",["gym"])],
 back:[ex("Superman","Superman Hold","time"),ex("One-Arm_Dumbbell_Row","One-Arm Dumbbell Row","reps",DUMB),ex("Band_Pull_Apart","Band Pull-Apart","reps",["bands"]),ex("Back_Flyes_-_With_Bands","Band Back Fly","reps",["bands"]),ex("Seated_Cable_Rows","Seated Cable Row","reps",["gym"]),ex("Wide-Grip_Lat_Pulldown","Lat Pulldown","reps",["gym"])],
 shoulders:[ex("Side_Lateral_Raise","Dumbbell Lateral Raise","reps",DUMB),ex("Lateral_Raise_-_With_Bands","Band Lateral Raise","reps",["bands"]),ex("Dumbbell_Shoulder_Press","Dumbbell Shoulder Press","reps",DUMB,1),ex("Shoulder_Press_-_With_Bands","Band Shoulder Press","reps",["bands"]),ex("Reverse_Flyes","Dumbbell Rear Fly","reps",DUMB),ex("Incline_Push-Up_Wide","Wide Incline Push-Up"),ex("Push_Up_to_Side_Plank","Push-Up to Side Plank","reps",ALL,1),ex("Plank","Plank Hold","time")],
 arms:[ex("Dumbbell_Bicep_Curl","Dumbbell Biceps Curl","reps",DUMB),ex("Hammer_Curls","Hammer Curl","reps",DUMB),ex("Standing_Dumbbell_Triceps_Extension","Overhead Triceps Extension","reps",DUMB),ex("Speed_Band_Overhead_Triceps","Band Overhead Triceps","reps",["bands"]),ex("Band_Skull_Crusher","Band Skull Crusher","reps",["bands"]),ex("Dips_-_Triceps_Version","Chair Dips (sturdy chair)","reps",ALL,1),ex("Incline_Push-Up_Close-Grip","Close-Grip Incline Push-Up"),ex("Triceps_Pushdown","Cable Triceps Pushdown","reps",["gym"]),ex("Machine_Bicep_Curl","Machine Biceps Curl","reps",["gym"])],
 core:[ex("Plank","Plank Hold","time"),ex("Dead_Bug","Dead Bug"),ex("Crunches","Crunch"),ex("Reverse_Crunch","Reverse Crunch"),ex("Side_Bridge","Side Plank (each side)","time"),ex("Russian_Twist","Russian Twist","reps",ALL,1),ex("Flutter_Kicks","Flutter Kicks","time",ALL,1),ex("Mountain_Climbers","Mountain Climbers","time",ALL,1,true),ex("Dumbbell_Side_Bend","Dumbbell Side Bend","reps",DUMB),ex("Cable_Crunch","Cable Crunch","reps",["gym"])],
 legs:[ex("Bodyweight_Squat","Bodyweight Squat"),ex("Dumbbell_Squat","Dumbbell Squat","reps",DUMB),ex("Squats_-_With_Bands","Band Squat","reps",["bands"]),ex("Bodyweight_Walking_Lunge","Walking Lunge"),ex("Dumbbell_Lunges","Dumbbell Lunge","reps",DUMB,1),ex("Step-up_with_Knee_Raise","Step-Up with Knee Raise"),ex("Dumbbell_Step_Ups","Dumbbell Step-Up","reps",DUMB,1),ex("Stiff-Legged_Dumbbell_Deadlift","Dumbbell Romanian Deadlift","reps",DUMB,1),ex("Calf_Raises_-_With_Bands","Band Calf Raise","reps",["bands"]),ex("Standing_Dumbbell_Calf_Raise","Dumbbell Calf Raise","reps",DUMB),ex("Leg_Press","Leg Press","reps",["gym"]),ex("Leg_Extensions","Leg Extension","reps",["gym"]),ex("Seated_Leg_Curl","Seated Leg Curl","reps",["gym"])],
 glutes:[ex("Butt_Lift_Bridge","Glute Bridge"),ex("Single_Leg_Glute_Bridge","Single-Leg Glute Bridge","reps",ALL,1),ex("Hip_Extension_with_Bands","Band Hip Extension","reps",["bands"]),ex("Stiff-Legged_Dumbbell_Deadlift","Dumbbell Romanian Deadlift","reps",DUMB,1),ex("Step-up_with_Knee_Raise","Step-Up with Knee Raise"),ex("Barbell_Hip_Thrust","Barbell Hip Thrust","reps",["gym"],2),ex("Leg_Press","Leg Press (feet high)","reps",["gym"])],
 cardio:[ex("Trail_Running_Walking","Brisk Walk or Easy Jog","time"),ex("Walking_Treadmill","Treadmill Walk","time",["gym"]),ex("Mountain_Climbers","Mountain Climbers","time",ALL,1,true),ex("Star_Jump","Star Jumps","time",ALL,1,true),ex("Double_Leg_Butt_Kick","Butt Kicks","time",ALL,1,true)],
 mobility:[ex("Cat_Stretch","Cat Stretch","time"),ex("Standing_Hip_Circles","Standing Hip Circles","time"),ex("Round_The_World_Shoulder_Stretch","Shoulder Round-the-World","time"),ex("Arm_Circles","Arm Circles","time"),ex("Childs_Pose","Child's Pose","time"),ex("Kneeling_Hip_Flexor","Kneeling Hip Flexor Stretch","time"),ex("Chin_To_Chest_Stretch","Neck Stretch (gentle)","time")]
};
const WARMUP=[ex("Arm_Circles","Arm Circles","time"),ex("Standing_Hip_Circles","Standing Hip Circles","time"),ex("Cat_Stretch","Cat Stretch","time")];
const COOLDOWN={
 legs:["Standing_Hamstring_and_Calf_Stretch","All_Fours_Quad_Stretch","Kneeling_Hip_Flexor"],
 glutes:["Kneeling_Hip_Flexor","Childs_Pose","Standing_Hamstring_and_Calf_Stretch"],
 chest:["Chest_And_Front_Of_Shoulder_Stretch","Triceps_Stretch","Round_The_World_Shoulder_Stretch"],
 shoulders:["Round_The_World_Shoulder_Stretch","Chest_And_Front_Of_Shoulder_Stretch","Triceps_Stretch"],
 arms:["Triceps_Stretch","Chest_And_Front_Of_Shoulder_Stretch","Round_The_World_Shoulder_Stretch"],
 back:["Childs_Pose","Cat_Stretch","Chin_To_Chest_Stretch"],
 core:["Childs_Pose","Cat_Stretch","Kneeling_Hip_Flexor"],
 cardio:["Standing_Hamstring_and_Calf_Stretch","Calf_Stretch_Hands_Against_Wall","All_Fours_Quad_Stretch"],
 mobility:["Childs_Pose","Chin_To_Chest_Stretch","Kneeling_Hip_Flexor"],
 full:["Standing_Hamstring_and_Calf_Stretch","Chest_And_Front_Of_Shoulder_Stretch","Childs_Pose"]
};
const FULL_ORDER=["legs","chest","back","core","glutes","shoulders"];
let shuffleSeed=0, lastPlanData=null;
function exName(db){return (EX_DB[db]&&EX_DB[db].name)||db.replace(/_/g," ");}
function prescription(item,d){
 const lvl={beginner:0,some:1,regular:2}[d.level]??0;
 const g=d.goal;
 let sets=[2,3,3][lvl], reps="10", secs=[20,30,40][lvl], rest="45–60 sec rest";
 if(g==="strength"){reps=lvl===0?"10":"8–12";rest="60–90 sec rest";if(lvl===2)sets=4;}
 else if(g==="fitness"){reps="12–15";rest="30–45 sec rest";}
 else if(g==="mobility"){sets=2;reps="8–10 slow";secs=[20,25,30][lvl];rest="Breathe, then continue";}
 else if(g==="energy"){sets=2;reps="10";secs=[15,20,30][lvl];rest="Rest as needed";}
 const text=item.type==="time"?`${sets} × ${secs} sec`:`${sets} × ${reps}`;
 return {text,rest};
}
function exCard(item,d,extra=""){
 const info=EX_DB[item.db]||{muscle:"",steps:[]};
 const p=prescription(item,d);
 const label=extra||p.text;
 return `<button type="button" class="ex-card" data-ex="${esc(item.db)}" data-name="${esc(item.name)}" data-presc="${esc(label+(extra?"":" · "+p.rest))}">`+
  `<span class="ex-media"><img src="images/${esc(item.db)}/0.jpg" loading="lazy" alt="${esc(item.name)} start position"><img class="alt" src="images/${esc(item.db)}/1.jpg" loading="lazy" alt="${esc(item.name)} finish position"></span>`+
  `<span class="ex-body"><strong>${esc(item.name)}</strong><small>${esc(info.muscle||"")}</small><span class="ex-presc">${esc(label)}</span></span></button>`;
}
function eligible(target,d,effEq,allowHi){
 const lvl={beginner:0,some:1,regular:2}[d.level]??0;
 const pool=(LIB[target]||[]);
 let list=pool.filter(e=>e.eq.includes(effEq)&&e.lv<=lvl&&(allowHi||!e.hi));
 if(!list.length)list=pool.filter(e=>e.eq.includes(effEq)&&(allowHi||!e.hi));
 if(!list.length)list=pool.filter(e=>e.eq.includes("none")&&!e.hi);
 // equipment-specific exercises first, so dumbbells/bands/gym users actually use their kit
 return [...list.filter(e=>e.eq.length<ALL.length),...list.filter(e=>e.eq.length===ALL.length)];
}
function pickMain(targets,count,dayIndex,d,effEq,allowHi){
 const used=new Set(),picked=[];
 const pools=targets.map(t=>eligible(t,d,effEq,allowHi));
 let round=0,guard=0;
 while(picked.length<count&&guard++<60){
  for(let ti=0;ti<targets.length&&picked.length<count;ti++){
   const pool=pools[ti];if(!pool.length)continue;
   const offset=(dayIndex+shuffleSeed)*1+round;
   for(let k=0;k<pool.length;k++){
    const cand=pool[(offset+k)%pool.length];
    if(!used.has(cand.db)){used.add(cand.db);picked.push(cand);break;}
   }
  }
  round++;
  if(round>6&&picked.length===0)break;
 }
 return picked;
}
function workoutHtml(d){
 const daysOfWeek={2:["Monday","Thursday"],3:["Monday","Wednesday","Friday"],4:["Monday","Tuesday","Thursday","Saturday"],5:["Monday","Tuesday","Thursday","Friday","Saturday"]}[d.days]||["Monday","Wednesday","Friday"];
 const targetNames={full:"Full body",chest:"Chest",back:"Back",shoulders:"Shoulders",arms:"Arms",core:"Core / abs",legs:"Legs",glutes:"Glutes",cardio:"Cardio",mobility:"Mobility"};
 const chosen=d.targets.includes("full")||!d.targets.length?["full"]:d.targets;
 const effEq=(d.place==="outdoors"&&d.equipment==="gym")?"none":d.equipment;
 const allowHi=d.level!=="beginner"&&d.limits==="none";
 const duration=d.duration==="15"?"15–20 min":d.duration==="45"?"40–50 min":"25–35 min";
 const mainCount=d.duration==="15"?3:d.duration==="45"?6:5;
 const coolCount=d.duration==="15"?1:2;
 const warmCount=d.duration==="15"?1:2;
 const intensity=d.level==="beginner"?"Start with an easy round and rest whenever needed.":d.level==="some"?"Controlled form first; add a round when it feels easy.":"Add a round only if your form stays steady.";
 return daysOfWeek.map((day,i)=>{
  let dayTargets;
  if(chosen[0]==="full"){
   const start=(i+shuffleSeed)%FULL_ORDER.length;
   dayTargets=Array.from({length:Math.min(mainCount,FULL_ORDER.length)},(_,k)=>FULL_ORDER[(start+k)%FULL_ORDER.length]);
  }else{
   dayTargets=chosen.filter((_,idx)=>idx%daysOfWeek.length===i);
   if(!dayTargets.length)dayTargets=[chosen[i%chosen.length]];
  }
  const main=pickMain(dayTargets,mainCount,i,d,effEq,allowHi);
  const warm=Array.from({length:warmCount},(_,k)=>WARMUP[(i+k+shuffleSeed)%WARMUP.length]);
  const coolKey=chosen[0]==="full"?"full":dayTargets[0];
  const coolList=COOLDOWN[coolKey]||COOLDOWN.full;
  const cool=Array.from({length:coolCount},(_,k)=>ex(coolList[(i+k+shuffleSeed)%coolList.length],exName(coolList[(i+k+shuffleSeed)%coolList.length]),"time"));
  const targetLabel=chosen[0]==="full"?"Full body":dayTargets.map(t=>targetNames[t]||t).join(" + ");
  const warmCards=warm.map(e=>exCard(e,d,"30 sec")).join("");
  const coolCards=cool.map(e=>exCard(e,d,"30 sec each side")).join("");
  const mainCards=main.map(e=>exCard(e,d)).join("");
  return `<article class="day-card"><div class="day-head"><strong>${esc(day.toUpperCase())} · SESSION 0${i+1}</strong><span class="tag">${esc(targetLabel)}</span></div><p class="day-note">${esc(targetLabel)} focus · ${duration}. ${esc(intensity)} Do the main exercises one after another, then repeat for the sets shown. Stop if you feel pain, dizziness or unusual breathlessness.</p><div class="ex-label">WARM-UP</div><div class="ex-grid">${warmCards}</div><div class="ex-label">MAIN WORK</div><div class="ex-grid">${mainCards}</div><div class="ex-label">COOL-DOWN</div><div class="ex-grid">${coolCards}</div></article>`;
 }).join("")+`<div class="food-group"><h4>REST / RECOVERY DAYS</h4><p>Use the days not listed for rest, an easy walk, or gentle mobility. You do not need to train every body part every day.</p></div>`;
}
/* ===== Exercise detail popup ===== */
let lastFocus=null;
function openEx(btn){
 const db=btn.dataset.ex,info=EX_DB[db]||{name:btn.dataset.name,muscle:"",steps:[]};
 lastFocus=btn;
 $("exImg0").src=`images/${db}/0.jpg`;$("exImg0").alt=`${btn.dataset.name} start position`;
 $("exImg1").src=`images/${db}/1.jpg`;$("exImg1").alt=`${btn.dataset.name} finish position`;
 $("exTitle").textContent=btn.dataset.name;
 $("exMuscle").textContent=("MAIN MUSCLE · "+(info.muscle||"full body")).toUpperCase();
 $("exPresc").textContent=btn.dataset.presc||"";
 $("exSteps").innerHTML=(info.steps&&info.steps.length?info.steps:["Move slowly and keep control through the whole range."]).map(s=>`<li>${esc(s)}</li>`).join("");
 $("exModal").classList.remove("hidden");document.body.classList.add("modal-open");
 $("exClose").focus();
}
function closeEx(){
 $("exModal").classList.add("hidden");document.body.classList.remove("modal-open");
 if(lastFocus&&document.body.contains(lastFocus))lastFocus.focus();
}
document.addEventListener("click",e=>{
 const card=e.target.closest&&e.target.closest(".ex-card");
 if(card){openEx(card);return;}
 if(e.target.id==="exClose"||(e.target.dataset&&e.target.dataset.close))closeEx();
});
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&!$("exModal").classList.contains("hidden"))closeEx();});
// If an exercise photo fails to load, hide it instead of showing a broken icon.
document.addEventListener("error",e=>{if(e.target&&e.target.tagName==="IMG")e.target.style.visibility="hidden";},true);
$("shuffleBtn").addEventListener("click",()=>{
 if(!lastPlanData)return;
 shuffleSeed++;
 $("workoutPlan").innerHTML=workoutHtml(lastPlanData);
});

function foodHtml(d){
 const m=meals[d.food];const cook=d.cooking==="quick"?"Quick options: yoghurt/soy yoghurt, fruit, beans, bread or roti, and frozen/pre-cut vegetables.":d.cooking==="hostel"?"Canteen pattern: combine a staple such as rice/roti, a protein food such as dal/beans/eggs/paneer/tofu, and vegetables when available.":"At home, keep meals familiar: a staple, a protein food, and vegetables or fruit.";
 const routine=d.mealCount==="varies"?"Meal timing can vary; try to have regular opportunities to eat and keep an easy snack available.":"Use this as a flexible idea list, not a strict schedule. Eat enough to feel satisfied and add snacks when hungry.";
 const allergen=d.allergies?`<div class="food-group"><h4>ALLERGY / AVOID REMINDER</h4><p>You entered: ${esc(d.allergies)}. Check labels and cross-contact; this tool cannot verify allergen safety.</p></div>`:"";
 return [["BREAKFAST IDEAS",m.breakfast],["LUNCH IDEAS",m.lunch],["SNACK IDEAS",m.snack],["DINNER IDEAS",m.dinner]].map(([h,arr])=>`<div class="food-group"><h4>${h}</h4><p>${arr.map(esc).join(" · ")}</p></div>`).join("")+
 `<div class="food-group"><h4>MAKE IT FIT YOUR DAY</h4><p>${esc(cook)} ${esc(routine)}</p></div>${allergen}
 <div class="food-group"><h4>WHAT TO LIMIT — WITHOUT STRICT RULES</h4><div class="avoid"><span>↘</span><div>Try not to rely on sugary drinks or packaged snacks as your main nourishment. No food needs to be labelled “bad,” and treats can fit too.</div></div><div class="avoid"><span>↘</span><div>Avoid crash diets, skipping meals, detoxes, or unverified supplements. They aren't needed for healthy habits.</div></div><div class="avoid"><span>↘</span><div>Drink water regularly; let thirst, activity and weather guide you.</div></div></div>`;
}
function proteinHtml(d){
 const rows=getFoodRows().map(r=>({key:r.querySelector(".log-food").value,qty:Number(r.querySelector(".portion-value").textContent)}));
 const total=rows.reduce((s,r)=>s+foodProtein[r.key].protein*r.qty,0);
 const byFood=rows.map(r=>({name:foodProtein[r.key].label,grams:foodProtein[r.key].protein*r.qty})).sort((a,b)=>b.grams-a.grams);
 // Do not give a weight-based protein target to minors; adult reference is not individualized advice either.
 let targetText, note;
 if(d.age<18){targetText="No target set";note="During the teen years, protein and energy needs vary with growth, development and activity. This tool won't prescribe a grams-per-day target. Eat regular, varied meals and ask a qualified healthcare professional for personalized guidance.";}
 else {targetText="Not prescribed";note="Protein needs depend on health, activity and goals. Rather than prescribing a personal target from a simple calculator, use this estimate to notice food sources and discuss individual needs with a qualified professional if needed.";}
 return `<div class="protein-summary"><div class="protein-box"><small>ESTIMATED FROM YOUR LOG</small><strong>${total} g</strong><p>Approximate protein for the listed foods and portions only.</p></div><div class="protein-box"><small>DAILY PROTEIN TARGET</small><strong style="font-size:18px">${targetText}</strong><p>Not a pass/fail score or a requirement to chase.</p></div></div><div class="protein-note">${esc(note)}</div><table class="protein-table">${byFood.map(r=>`<tr><td>${esc(r.name)}</td><td>${r.grams} g</td></tr>`).join("")}</table><p style="font-size:9px;color:#788678;line-height:1.7;margin:12px 0 0">Rough averages only; recipes, brands and serving sizes can change the amount. Add the rest of your day's food for a more complete estimate.</p>`;
}
function makePlan(e){
 e.preventDefault();
 if(!validatePanel(4)||!$("understand").checked){$("understand").reportValidity();return;}
 const d=getData();
 $("resultTitle").textContent=d.name?`${d.name}, here's your starting plan.`:"Your starting plan is ready.";
 $("resultSubtitle").textContent=`${d.days} planned sessions · ${({strength:"Strength foundations",fitness:"Everyday fitness",mobility:"Mobility and movement",energy:"Everyday energy"})[d.goal]} · Built around your preferences`;
 const energy=calcEnergy(d);
 const metricData=[
  ["PROFILE",`${d.height} cm / ${d.weight} kg`,"For context only; body measurements aren't a grade.",false],
  ["ENERGY ESTIMATE",energy?`${energy.toLocaleString()} kcal/day`:"No number shown",d.age<18?"Not calculated for under-18s.":d.sex==="unsure"?"Choose not to disclose; estimate skipped.":"Very rough adult maintenance estimate, not a calorie limit.",true],
  ["WEEKLY MOVEMENT",`${d.days} days`,"Rest and recovery count, too.",false],
  ["FOOD LOG PROTEIN",`${getFoodRows().reduce((s,r)=>s+rowProtein(r),0)} g`,"Only the foods you entered; estimates vary.",false]
 ];
 $("metrics").innerHTML=metricData.map(m=>`<div class="metric ${m[3]?"accent":""}"><small>${m[0]}</small><strong>${esc(m[1])}</strong><p>${esc(m[2])}</p></div>`).join("");
 lastPlanData=d;shuffleSeed=0;
 $("workoutPlan").innerHTML=workoutHtml(d);
 $("foodPlan").innerHTML=foodHtml(d);
 $("proteinSummary").innerHTML=proteinHtml(d);
 $("habitPlan").innerHTML=[
  "Warm up gently and use comfortable variations.",
  "Take rest days; adapt or skip a session if unwell.",
  "Eat regular, satisfying meals and snacks when hungry.",
  "Build a sleep routine that suits your age and schedule."
 ].map(t=>`<div class="habit-item"><span>✳</span><p>${esc(t)}</p></div>`).join("");
 const notices=[];
 if(d.age<18)notices.push("Because you entered an age under 18, no calorie target or weight-based protein target is provided. Growth and nutrition needs are individual; involve a trusted adult and a qualified healthcare professional for personal guidance.");
 if(d.limits==="health")notices.push("You selected a health condition, injury or recovery. Check with a healthcare professional before using exercise suggestions.");
 if(d.limits==="joint")notices.push("You selected movement limitations. Skip any movement that aggravates symptoms and ask a qualified professional about alternatives.");
 if(d.limits==="unsure")notices.push("If you're unsure what is suitable, start only with comfortable gentle movement and ask a qualified professional for guidance.");
 $("safetyNotice").innerHTML=notices.map(t=>`<p style="margin:0 0 5px">${esc(t)}</p>`).join("");
 $("safetyNotice").classList.toggle("hidden",!notices.length);
 results.classList.remove("hidden");
 results.scrollIntoView({behavior:"smooth",block:"start"});
}
form.addEventListener("submit",makePlan);
$("printBtn").addEventListener("click",()=>window.print());
$("editBtn").addEventListener("click",()=>{results.classList.add("hidden");setPanel(1);});
updateFoodLog();
